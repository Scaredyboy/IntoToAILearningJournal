import tkinter as tk
import random
from utils import load_data, is_dark
from html_exporter import save_theme_as_html

class PaletteApp:
    def __init__(self, root):
        self.preview_header = None
        self.color_frame = None
        self.root = root
        self.root.title("Color + Font Palette Generator")
        self.root.geometry("500x500")
        self.root.config(bg="#f0f0f0")

        # Load data
        self.color_palettes, self.font_pairs = load_data()

        # State
        self.current_palette = []
        self.current_fonts = ()
        self.is_dark_mode = False
        self.mode_var = tk.StringVar(value="☀️ Light Mode")

        # Build UI
        self.create_widgets()
        self.generate_palette()

    # -------------------------
    # MODE FUNCTIONALITY
    # -------------------------
    def toggle_mode(self):
        self.is_dark_mode = not self.is_dark_mode
        self.mode_var.set("🌙 Dark Mode" if self.is_dark_mode else "☀️ Light Mode")
        
        # Update button appearances
        button_bg = "#333333" if self.is_dark_mode else "#f0f0f0"
        button_fg = "white" if self.is_dark_mode else "black"
        
        for button in self.buttons:
            button.config(
                bg=button_bg,
                fg=button_fg,
                activebackground="#444444" if self.is_dark_mode else "#e0e0e0",
                activeforeground=button_fg
            )
        
        self.generate_palette()

    def filter_palettes_by_mode(self):
        filtered = []
        
        # First pass: strict filtering based on primary color
        for palette in self.color_palettes:
            # Skip empty palettes
            if not palette:
                continue
                
            # Check if the primary (first) color matches our mode
            primary_is_dark = is_dark(palette[0])
            if self.is_dark_mode == primary_is_dark:
                filtered.append(palette)
        
        # Second pass: more lenient filtering if needed
        if len(filtered) < 3:  # If we have very few options
            filtered = []  # Reset and try with looser criteria
            for palette in self.color_palettes:
                if not palette:  # Skip empty palettes
                    continue
                    
                dark_count = sum(1 for color in palette if is_dark(color))
                if self.is_dark_mode:
                    # For dark mode, accept if at least 1/3 colors are dark
                    if dark_count >= len(palette) / 3:
                        filtered.append(palette)
                else:
                    # For light mode, accept if at least 1/3 colors are light
                    if dark_count <= len(palette) * 2/3:
                        filtered.append(palette)
        
        print(f"Filtered palettes for {'dark' if self.is_dark_mode else 'light'} mode: {len(filtered)}")
        
        # If we still have no valid palettes, return all non-empty palettes
        return filtered if filtered else [p for p in self.color_palettes if p]

    # -------------------------
    # CLIPBOARD FUNCTIONALITY
    # -------------------------
    def copy_to_clipboard(self, text):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.show_copy_feedback(text)

    def show_copy_feedback(self, text):
        # Create a temporary label for feedback
        feedback = tk.Label(
            self.root,
            text=f"Copied: {text}",
            bg="#4CAF50",
            fg="white",
            padx=10,
            pady=5
        )
        feedback.place(relx=0.5, rely=0.9, anchor="center")
        # Remove the feedback label after 1.5 seconds
        self.root.after(1500, feedback.destroy)

    # -------------------------
    # UI SETUP
    # -------------------------
    def create_widgets(self):
        tk.Label(
            self.root, text="🎨 Color & Font Palette Generator",
            font=("Helvetica", 16, "bold"), bg="#f0f0f0"
        ).pack(pady=10)

        self.color_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.color_frame.pack(pady=10)

        self.preview_frame = tk.Frame(self.root, bg="#ffffff", relief="groove", bd=2)
        self.preview_frame.pack(pady=15, fill="both", expand=True, padx=20)

        self.preview_header = tk.Label(
            self.preview_frame, text="Header Example",
            font=("Arial", 18, "bold"),
            cursor="hand2"
        )
        self.preview_header.pack(pady=(20, 10))
        self.preview_header.bind("<Button-1>", lambda e: self.copy_to_clipboard(self.current_fonts[0]))

        self.preview_body = tk.Label(
            self.preview_frame,
            text="This is an example of how your font pairing and colors might look together.",
            wraplength=400, font=("Times New Roman", 12),
            cursor="hand2"
        )
        self.preview_body.pack(pady=(0, 20))
        self.preview_body.bind("<Button-1>", lambda e: self.copy_to_clipboard(self.current_fonts[1]))

        btn_frame = tk.Frame(self.root, bg="#f0f0f0")
        btn_frame.pack(pady=10)

        tk.Button(
            btn_frame, text="Generate New Theme", command=self.generate_palette
        ).grid(row=0, column=0, padx=10)

        tk.Button(
            btn_frame, text="Save as HTML", command=self.save_theme
        ).grid(row=0, column=1, padx=10)

        # Mode toggle button
        self.mode_button = tk.Button(
            btn_frame,
            textvariable=self.mode_var,
            command=self.toggle_mode,
            width=12,
            relief="raised",
            borderwidth=2
        )
        self.mode_button.grid(row=0, column=2, padx=10)
        
        # Store references to buttons for theme updates
        self.buttons = [
            widget for widget in btn_frame.winfo_children() 
            if isinstance(widget, tk.Button)
        ]

    # -------------------------
    # CORE FUNCTIONALITY
    # -------------------------
    def generate_palette(self):
        filtered_palettes = self.filter_palettes_by_mode()
        
        # Debug information
        mode = "dark" if self.is_dark_mode else "light"
        print(f"Mode: {mode}")
        print(f"Available palettes: {len(filtered_palettes)} / {len(self.color_palettes)}")
        
        # If we have no filtered palettes, use any palette
        if not filtered_palettes:
            filtered_palettes = self.color_palettes
            print("No matching palettes found, using all palettes")
        
        # Choose a different palette if possible
        if self.current_palette in filtered_palettes and len(filtered_palettes) > 1:
            filtered_palettes.remove(self.current_palette)
        
        # Select a new palette
        self.current_palette = random.choice(filtered_palettes)
        print(f"Selected palette: {self.current_palette}")
        
        # Select new fonts
        self.current_fonts = random.choice(self.font_pairs)
        self.update_display()

    def update_display(self):
        # Update the app background based on mode
        bg_color = "#2c2c2c" if self.is_dark_mode else "#f0f0f0"
        self.root.config(bg=bg_color)
        self.color_frame.config(bg=bg_color)

        # Clear old color blocks
        for widget in self.color_frame.winfo_children():
            widget.destroy()

        # Update the button frame background
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame):
                widget.config(bg=bg_color)

        for color in self.current_palette:
            lbl = tk.Label(
                self.color_frame,
                bg=color, width=10, height=2,
                text=color, fg="white" if is_dark(color) else "black",
                cursor="hand2"  # Changes cursor to hand when hovering
            )
            lbl.pack(side="left", padx=5)
            # Bind click event to copy color code
            lbl.bind("<Button-1>", lambda e, c=color: self.copy_to_clipboard(c))

        header_font, body_font = self.current_fonts
        
        # Get background and text colors from the palette
        preview_bg = self.current_palette[0]  # Primary color
        preview_text_color = "white" if is_dark(preview_bg) else "black"

        # Update preview frame
        self.preview_frame.config(bg=preview_bg)
        
        # Update header
        self.preview_header.config(
            font=(header_font, 18, "bold"),
            bg=preview_bg,
            fg=preview_text_color
        )
        
        # Update body
        self.preview_body.config(
            font=(body_font, 12),
            bg=preview_bg,
            fg=preview_text_color
        )
        
        # Update title label
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Label):
                widget.config(bg=bg_color, fg="white" if self.is_dark_mode else "black")

    def save_theme(self):
        save_theme_as_html(self.current_palette, self.current_fonts)
