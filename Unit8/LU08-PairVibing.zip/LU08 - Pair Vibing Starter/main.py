import tkinter as tk
from app import PaletteApp

# run this
if __name__ == "__main__":
    root = tk.Tk()
    app = PaletteApp(root)
    root.mainloop()
