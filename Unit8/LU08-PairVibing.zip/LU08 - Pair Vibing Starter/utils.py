import json

def load_data(file_path="data.json"):
    """Load color palettes and font pairs from JSON."""
    with open(file_path, "r") as f:
        data = json.load(f)
    return data["color_palettes"], data["font_pairs"]

def is_dark(hex_color):
    """Determine if text should be white or black based on brightness."""
    hex_color = hex_color.lstrip("#")
    r, g, b = tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    brightness = (r * 299 + g * 587 + b * 114) / 1000
    return brightness < 128
