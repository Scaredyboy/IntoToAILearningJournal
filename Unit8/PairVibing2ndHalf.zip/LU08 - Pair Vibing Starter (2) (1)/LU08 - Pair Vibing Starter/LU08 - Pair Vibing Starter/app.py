import tkinter as tk
from tkinter import colorchooser, simpledialog, messagebox
import random
import requests
import json
from utils import load_data, is_dark
from html_exporter import save_theme_as_html

# Popular Google Fonts list
GOOGLE_FONTS = [
    "Roboto", "Open Sans", "Lato", "Montserrat", "Raleway",
    "Poppins", "Source Sans Pro", "Ubuntu", "Playfair Display",
    "Merriweather", "Nunito", "Rubik", "Work Sans", "Noto Sans",
    "PT Sans", "Oswald", "Inter", "Quicksand", "Mulish", "Fira Sans"
]

class PaletteApp:
    def __init__(self, root):
        self.preview_header = None
        self.color_frame = None
        self.root = root
        self.root.title("Color + Font Palette Generator")
        self.root.geometry("500x500")
        self.root.config(bg="#f0f0f0")

        # Load data
        self.color_palettes, self.font_pairs = load_data()

        # State
        self.current_palette = []
        self.current_fonts = ()
        self.selected_color = None  # None means choose randomly
        # Build list of available colors (flat unique list)
        flat_colors = [c for p in self.color_palettes for c in p]
        # preserve order but make unique
        seen = set()
        self.available_colors = [x for x in flat_colors if not (x in seen or seen.add(x))]

        # Build list of available fonts (flat unique list)
        flat_fonts = [f for pair in self.font_pairs for f in pair]
        seen_fonts = set()
        self.available_fonts = [x for x in flat_fonts if not (x in seen_fonts or seen_fonts.add(x))]
        
        # Load Google Fonts
        self.google_fonts = []
        self.load_google_fonts()
        
        # Add Google Fonts to available fonts
        self.available_fonts.extend(self.google_fonts)

        # Build UI
        self.create_widgets()
        self.generate_palette()
        
    def load_google_fonts(self):
        """Load predefined list of popular Google Fonts"""
        self.google_fonts = GOOGLE_FONTS
        
        # Create font data dictionary for HTML export
        self.google_font_data = {
            font: {'family': font} for font in GOOGLE_FONTS
        }
        
        print(f"Successfully loaded {len(self.google_fonts)} Google Fonts")

    # -------------------------
    # UI SETUP
    # -------------------------
    def create_widgets(self):
        tk.Label(self.root, text="🎨 Color & Font Palette Generator",
                 font=("Helvetica", 16, "bold"), bg="#f0f0f0").pack(pady=10)

        self.color_frame = tk.Frame(self.root, bg="#f0f0f0")
        self.color_frame.pack(pady=10)

        self.preview_frame = tk.Frame(self.root, bg="#ffffff", relief="groove", bd=2)
        self.preview_frame.pack(pady=15, fill="both", expand=True, padx=20)

        self.preview_header = tk.Label(self.preview_frame, text="Header Example",
                                       font=("Arial", 18, "bold"))
        self.preview_header.pack(pady=(20, 10))

        self.preview_body = tk.Label(self.preview_frame,
                                     text="This is an example of how your font pairing and colors might look together.",
                                     wraplength=400, font=("Times New Roman", 12))
        self.preview_body.pack(pady=(0, 20))

        # Color selection controls
        selection_frame = tk.Frame(self.root, bg="#f0f0f0")
        selection_frame.pack(pady=(0, 10))

        tk.Label(selection_frame, text="Select base color:", bg="#f0f0f0").grid(row=0, column=0, padx=(0, 8))
        choices = ["Random"] + self.available_colors
        self.color_var = tk.StringVar(value="Random")
        self.color_menu = tk.OptionMenu(selection_frame, self.color_var, *choices)
        self.color_menu.grid(row=0, column=1)
        tk.Button(selection_frame, text="Pick custom color", command=self.pick_custom_color).grid(row=0, column=2, padx=8)

        # Font selection controls
        font_frame = tk.Frame(self.root, bg="#f0f0f0")
        font_frame.pack(pady=(0, 10))

        tk.Label(font_frame, text="Header font:", bg="#f0f0f0").grid(row=0, column=0, padx=(0, 8))
        header_choices = ["Random"] + self.available_fonts
        self.header_var = tk.StringVar(value="Random")
        self.header_menu = tk.OptionMenu(font_frame, self.header_var, *header_choices)
        self.header_menu.grid(row=0, column=1, padx=(0, 8))

        tk.Label(font_frame, text="Body font:", bg="#f0f0f0").grid(row=0, column=2, padx=(8, 8))
        body_choices = ["Random"] + self.available_fonts
        self.body_var = tk.StringVar(value="Random")
        self.body_menu = tk.OptionMenu(font_frame, self.body_var, *body_choices)
        self.body_menu.grid(row=0, column=3, padx=(0, 8))

        tk.Button(font_frame, text="Add custom font", command=self.add_custom_font).grid(row=0, column=4)

        btn_frame = tk.Frame(self.root, bg="#f0f0f0")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="Generate New Theme", command=self.generate_palette).grid(row=0, column=0, padx=10)
        tk.Button(btn_frame, text="Save as HTML", command=self.save_theme).grid(row=0, column=1, padx=10)

    # -------------------------
    # CORE FUNCTIONALITY
    # -------------------------
    def generate_palette(self):
        # Determine selected color (if any)
        sel = self.color_var.get() if hasattr(self, 'color_var') else "Random"
        if sel == "Random" or sel == "":
            # full random behavior
            self.current_palette = random.choice(self.color_palettes)
        else:
            # use selected color (either from dropdown or custom picked)
            chosen_color = sel
            # find palettes that contain the chosen color
            matching = [p for p in self.color_palettes if chosen_color in p]
            if matching:
                # pick one of the matching palettes
                self.current_palette = random.choice(matching)
            else:
                # no full palette contains it: take a random palette and replace the first color
                base = random.choice(self.color_palettes).copy()
                base[0] = chosen_color
                self.current_palette = base

        # Determine selected fonts (if any)
        header_sel = self.header_var.get() if hasattr(self, 'header_var') else "Random"
        body_sel = self.body_var.get() if hasattr(self, 'body_var') else "Random"

        if (header_sel == "Random" or header_sel == "") and (body_sel == "Random" or body_sel == ""):
            self.current_fonts = random.choice(self.font_pairs)
        else:
            # Use selected fonts where provided; fallback to random pick for missing
            if header_sel == "Random" or header_sel == "":
                header_font = random.choice(self.available_fonts)
            else:
                header_font = header_sel

            if body_sel == "Random" or body_sel == "":
                # choose a different font for body when possible
                body_font = random.choice([f for f in self.available_fonts if f != header_font] or self.available_fonts)
            else:
                body_font = body_sel

            self.current_fonts = (header_font, body_font)
        self.update_display()

    def pick_custom_color(self):
        # Open color chooser and set selected color (converted to hex)
        color = colorchooser.askcolor(title="Choose a color")
        if color and color[1]:
            hex_color = color[1].upper()
            # if this color is not already in choices, add it to the menu
            if hex_color not in self.available_colors:
                self.available_colors.append(hex_color)
                # rebuild option menu choices
                menu = self.color_menu["menu"]
                menu.delete(0, "end")
                choices = ["Random"] + self.available_colors
                for choice in choices:
                    menu.add_command(label=choice, command=lambda v=choice: self.color_var.set(v))
            self.color_var.set(hex_color)

    def add_custom_font(self):
        # Prompt the user for a font name to add to the dropdowns
        font_name = simpledialog.askstring("Add Font", "Enter font name (e.g. 'Roboto'):")
        if font_name:
            font_name = font_name.strip()
            if font_name and font_name not in self.available_fonts:
                self.available_fonts.append(font_name)
                # rebuild header menu
                hmenu = self.header_menu["menu"]
                hmenu.delete(0, "end")
                for choice in ["Random"] + self.available_fonts:
                    hmenu.add_command(label=choice, command=lambda v=choice: self.header_var.set(v))
                # rebuild body menu
                bmenu = self.body_menu["menu"]
                bmenu.delete(0, "end")
                for choice in ["Random"] + self.available_fonts:
                    bmenu.add_command(label=choice, command=lambda v=choice: self.body_var.set(v))

    def copy_to_clipboard(self, text):
        """Copy text to clipboard and show temporary feedback."""
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.root.update()  # Required to finalize clipboard on Windows
        
        # Create temporary popup feedback
        popup = tk.Toplevel()
        popup.wm_overrideredirect(True)
        x = self.root.winfo_x() + self.root.winfo_width()//2 - 100
        y = self.root.winfo_y() + self.root.winfo_height()//2 - 25
        popup.geometry(f"200x50+{x}+{y}")
        
        tk.Label(popup, text=f"Copied to clipboard:\n{text}",
                padx=10, pady=5).pack(expand=True)
        
        popup.after(1000, popup.destroy)  # Destroy after 1 second

    def update_display(self):
        # Clear old color blocks
        for widget in self.color_frame.winfo_children():
            widget.destroy()

        for color in self.current_palette:
            lbl = tk.Label(
                self.color_frame,
                bg=color, width=10, height=2,
                text=color, fg="white" if is_dark(color) else "black",
                cursor="hand2"  # Change cursor to hand when hovering
            )
            lbl.pack(side="left", padx=5)
            # Bind click event to copy color
            lbl.bind('<Button-1>', lambda e, c=color: self.copy_to_clipboard(c))

        header_font, body_font = self.current_fonts
        self.preview_header.config(
            font=(header_font, 18, "bold"),
            cursor="hand2"  # Change cursor to hand when hovering
        )
        self.preview_body.config(
            font=(body_font, 12),
            cursor="hand2"  # Change cursor to hand when hovering
        )
        
        # Bind click events to copy font names
        self.preview_header.bind('<Button-1>', lambda e: self.copy_to_clipboard(header_font))
        self.preview_body.bind('<Button-1>', lambda e: self.copy_to_clipboard(body_font))
        
        self.preview_frame.config(bg=self.current_palette[0])
        self.preview_header.config(bg=self.current_palette[0])
        self.preview_body.config(bg=self.current_palette[0])

    def save_theme(self):
        # If a specific base color is selected, pass it to the exporter
        sel = self.color_var.get() if hasattr(self, 'color_var') else "Random"
        base = None if sel == "Random" else sel
        save_theme_as_html(
            self.current_palette, 
            self.current_fonts, 
            base_color=base,
            google_font_data=getattr(self, 'google_font_data', None)
        )
