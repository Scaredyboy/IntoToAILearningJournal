from datetime import datetime
from utils import is_dark
from pathlib import Path
from string import Template

TEMPLATE_PATH = Path(__file__).parent / "templates" / "theme_template.html"

def save_theme_as_html(colors, fonts, base_color=None, google_font_data=None):
    """Generate an HTML file from the theme template using string.Template."""
    header_font, body_font = fonts
    
    # Build Google Fonts link
    fonts_to_load = set()
    if google_font_data and (header_font in google_font_data or body_font in google_font_data):
        if header_font in google_font_data:
            fonts_to_load.add(header_font)
        if body_font in google_font_data:
            fonts_to_load.add(body_font)
    
    google_fonts_link = ""
    if fonts_to_load:
        font_families = "|".join(f"{font.replace(' ', '+')}" for font in fonts_to_load)
        google_fonts_link = f'<link href="https://fonts.googleapis.com/css2?family={" ".join(f"family={f.replace(" ", "+")}&display=swap" for f in fonts_to_load)}" rel="stylesheet">'

    # Generate HTML for color blocks
    color_blocks = ""
    for color in colors:
        text_color = "white" if is_dark(color) else "black"
        color_blocks += f'<div class="color" style="background-color:{color}; color:{text_color};">{color}</div>\n'

    # Load template
    with open(TEMPLATE_PATH, "r") as f:
        template = Template(f.read())

    # Choose bg/text/header colors with optional override for bg
    bg_color = base_color if base_color else (colors[0] if len(colors) > 0 else "#ffffff")
    text_color = colors[1] if len(colors) > 1 else "#000000"
    header_color = colors[2] if len(colors) > 2 else bg_color

    # Substitute placeholders
    html_content = template.substitute(
        bg_color=bg_color,
        text_color=text_color,
        header_color=header_color,
        header_font=header_font,
        body_font=body_font,
        color_blocks=color_blocks,
        google_fonts_link=google_fonts_link
    )

    # Save HTML file
    filename = f"theme_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    with open(filename, "w") as f:
        f.write(html_content)

    print(f"✅ Theme saved as {filename}")
    return filename
