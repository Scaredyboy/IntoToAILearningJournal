# Pyhon Pair Vibing

In a group of 2-3, Vibe code the features outlined below.
Half way thought the project you will hand it off to another group for them to finish it.
This is an exercise in Vibe coding as well as working in other peoples code.
Make sure to test your program as you go.
Turn in the second code base.

## Running the Project

### Prerequisites

- And IDE, I recommend [Pycharm](https://www.jetbrains.com/pycharm/) or [VSCode](https://code.visualstudio.com/)
- [Python](https://www.python.org/) installed

### Run the in PyCharm

Just go to the [main.py](main.py) file and click on the green arrow next to line 5.


### Run the Project in the Terminal

[//]: # (TODO make this project not relay on PyCharm idk Terminal comands)

```bash
source venv/bin/activate
python main.py
```

## Part 1: Group 1

Using your vibe coding skills pick **TWO** features to add (leave the rest for the next group). 
Mark in the "Completed" category what features you added so the next group knows.

| Feature                  | Description                                                             | Completed | 
|--------------------------|-------------------------------------------------------------------------|-----------|
| Lock Colors or Fonts     | Allow the user to lock a color (or font) so only the others randomize.  | Done      |
| Copy Hex or Font Names   | Clicking on a color block or font copies it to clipboard.               |     X     |
| Light/dark mode switch   | Add a light and dark mode switch to change the colors that are output.  | Done      |
| Fonts API                | Use a Font API (like Google Fonts) to expand the number of fonts        |     X     |
| AI  Complementary Colors | Let AI (using local Ollama) suggest complementary colors using a prompt |           |

Your Goal is to add these features as fast as possible.
As long as it works it's good.
Quick and dirty is the name of the game.
Leave the mess for the next group.

---

### Fill Out Below

Before you send this project to the next group please leave them a note.
- All members in your team names.
  - What each team member did.
- How each feature you added works.
- Anything else you think the next group should know.
  - Errors.
  - Missing features
  - Tech debt

```
Members: Jose Camacho, Mason Schmidtke
(Jose) - For the light/dark mode switch, I used ChatGPT to update the html code to add a light/dark 
(Mason) - For the color selection I'm using copilot to add the ability to select certain colors or fonts before generation.

```

## Part 2: Group 2

Look though the code base.
Take note of what works and what doesn't.
There should be three more features to add left.
Try to add at least **TWO** more.
If you have extra time add more features.

### Fill out the Below

Leave a review of the codebase you got.
How does it function.
Does it follow code standards?
Does it have good documentation? 

```
Ethan Umphress, Conrad Parker, Cody Carroll
We got an Error filled code that wouldnt open. 0/10. We told the clanker to fix the code and now it works. I hope the clanker did 
his job good enough that it would follow the standards. The clanker did add alot of Comments so it does have good documentation
```

## What to Turn in

- You worked on two different code bases. Please turn in the second one. Submit the entire project as a `.zip`.
- Include the edited `README.md` file
